module.exports=[25,(a,b,c)=>{}];

//# sourceMappingURL=netlify_my-app-latest__next-internal_server_app_home_page_actions_c1f0a6f0.js.map
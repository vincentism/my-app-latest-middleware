module.exports=[23550,(a,b,c)=>{}];

//# sourceMappingURL=netlify_my-app-latest__next-internal_server_app_en_page_actions_6be77fb0.js.map
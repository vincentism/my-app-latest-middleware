module.exports=[46663,(e,o,d)=>{}];

//# sourceMappingURL=af5ec_my-app-latest__next-internal_server_app_favicon_ico_route_actions_e7cd398f.js.map
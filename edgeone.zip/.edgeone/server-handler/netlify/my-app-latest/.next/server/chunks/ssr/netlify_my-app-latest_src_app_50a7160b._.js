module.exports=[59997,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},80165,a=>{"use strict";let b={src:a.i(59997).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=netlify_my-app-latest_src_app_50a7160b._.js.map
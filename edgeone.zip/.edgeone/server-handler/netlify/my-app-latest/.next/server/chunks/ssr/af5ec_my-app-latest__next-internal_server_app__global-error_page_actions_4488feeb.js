module.exports=[93972,(a,b,c)=>{}];

//# sourceMappingURL=af5ec_my-app-latest__next-internal_server_app__global-error_page_actions_4488feeb.js.map
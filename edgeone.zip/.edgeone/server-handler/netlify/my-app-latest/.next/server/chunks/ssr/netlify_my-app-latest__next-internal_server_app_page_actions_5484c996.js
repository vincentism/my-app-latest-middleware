module.exports=[54894,(a,b,c)=>{}];

//# sourceMappingURL=netlify_my-app-latest__next-internal_server_app_page_actions_5484c996.js.map
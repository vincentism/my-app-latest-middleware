module.exports=[18979,(a,b,c)=>{}];

//# sourceMappingURL=netlify_my-app-latest__next-internal_server_app__not-found_page_actions_30e2c04c.js.map
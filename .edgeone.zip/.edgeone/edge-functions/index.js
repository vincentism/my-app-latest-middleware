
      let global = globalThis;

      class MessageChannel {
        constructor() {
          this.port1 = new MessagePort();
          this.port2 = new MessagePort();
        }
      }
      class MessagePort {
        constructor() {
          this.onmessage = null;
        }
        postMessage(data) {
          if (this.onmessage) {
            setTimeout(() => this.onmessage({ data }), 0);
          }
        }
      }
      global.MessageChannel = MessageChannel;

      async function handleRequest(context){
        let routeParams = {};
        let pagesFunctionResponse = null;
        const request = context.request;
        const waitUntil = context.waitUntil;
        const urlInfo = new URL(request.url);

        if (urlInfo.pathname !== '/' && urlInfo.pathname.endsWith('/')) {
          urlInfo.pathname = urlInfo.pathname.slice(0, -1);
        }

        let matchedFunc = false;
        
          if(!matchedFunc && '/api' === urlInfo.pathname) {
            matchedFunc = true;
              "use strict";
(() => {
  // edge-functions/api/index.js
  function onRequest(context) {
    return new Response("Hello from Edge Functions!");
  }

        pagesFunctionResponse = onRequest;
      })();
          }
        

        const params = {};
        if (routeParams.id) {
          if (routeParams.mode === 1) {
            const value = urlInfo.pathname.match(routeParams.left);        
            for (let i = 1; i < value.length; i++) {
              params[routeParams.id[i - 1]] = value[i];
            }
          } else {
            const value = urlInfo.pathname.replace(routeParams.left, '');
            const splitedValue = value.split('/');
            if (splitedValue.length === 1) {
              params[routeParams.id] = splitedValue[0];
            } else {
              params[routeParams.id] = splitedValue;
            }
          }
          
        }
        if(!matchedFunc){
          pagesFunctionResponse = function() {
            return new Response(null, {
              status: 404,
              headers: {
                "content-type": "text/html; charset=UTF-8",
                "x-edgefunctions-test": "Welcome to use Pages Functions.",
              },
            });
          }
        }
        return pagesFunctionResponse({request, params, env: {"MallocNanoZone":"0","USER":"vincentlli","SECURITYSESSIONID":"186a3","COMMAND_MODE":"unix2003","__CFBundleIdentifier":"com.tencent.codebuddycn","PATH":"/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/3823_1764301444320/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin:/Users/vincentlli/Documents/demo/h265/emsdk:/Users/vincentlli/Documents/demo/h265/emsdk/upstream/emscripten:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Library/Apple/usr/bin:/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/1172_1764301439509/bin:/Users/vincentlli/.deno/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/micromamba/condabin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","HOME":"/Users/vincentlli","SHELL":"/bin/zsh","LaunchInstanceID":"A4C3CE65-561F-40EB-8850-E06A56601406","__CF_USER_TEXT_ENCODING":"0x1F6:0x19:0x34","XPC_SERVICE_NAME":"0","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.4cmc7UUAl7/Listeners","XPC_FLAGS":"0x0","LOGNAME":"vincentlli","TMPDIR":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","SHLVL":"1","PWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","OLDPWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","HOMEBREW_PREFIX":"/opt/homebrew","HOMEBREW_CELLAR":"/opt/homebrew/Cellar","HOMEBREW_REPOSITORY":"/opt/homebrew","INFOPATH":"/opt/homebrew/share/info:/opt/homebrew/share/info:","EMSDK":"/Users/vincentlli/Documents/demo/h265/emsdk","EMSDK_NODE":"/Users/vincentlli/Documents/demo/h265/emsdk/node/16.20.0_64bit/bin/node","EMSDK_PYTHON":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/bin/python3","SSL_CERT_FILE":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/lib/python3.9/site-packages/certifi/cacert.pem","NVM_DIR":"/Users/vincentlli/.nvm","NVM_CD_FLAGS":"-q","NVM_BIN":"/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","NVM_INC":"/Users/vincentlli/.nvm/versions/node/v20.16.0/include/node","MAMBA_EXE":"/Users/vincentlli/.micromamba/bin/micromamba","MAMBA_ROOT_PREFIX":"/Users/vincentlli/micromamba","CONDA_SHLVL":"0","FNM_MULTISHELL_PATH":"/Users/vincentlli/.local/state/fnm_multishells/3823_1764301444320","FNM_VERSION_FILE_STRATEGY":"local","FNM_DIR":"/Users/vincentlli/.local/share/fnm","FNM_LOGLEVEL":"info","FNM_NODE_DIST_MIRROR":"https://nodejs.org/dist","FNM_COREPACK_ENABLED":"false","FNM_RESOLVE_ENGINES":"true","FNM_ARCH":"arm64","TERM_PROGRAM":"codebuddy","TERM_PROGRAM_VERSION":"1.100.0","LANG":"zh_CN.UTF-8","COLORTERM":"truecolor","GIT_ASKPASS":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass.sh","VSCODE_GIT_ASKPASS_NODE":"/Applications/CodeBuddy CN.app/Contents/Frameworks/CodeBuddy CN Helper (Plugin).app/Contents/MacOS/CodeBuddy CN Helper (Plugin)","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass-main.js","VSCODE_GIT_IPC_HANDLE":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/vscode-git-b9fbf10dc9.sock","VSCODE_INJECTION":"1","ZDOTDIR":"/Users/vincentlli","USER_ZDOTDIR":"/Users/vincentlli","TERM":"xterm-256color","VSCODE_PROFILE_INITIALIZED":"1","_":"/Users/vincentlli/.local/state/fnm_multishells/3823_1764301444320/bin/edgeone","XXX":"123","EDGEONE_MIDDLEWARE":"1","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil });
      }
      addEventListener('fetch', event=>{return event.respondWith(handleRequest({request:event.request,params: {}, env: {"MallocNanoZone":"0","USER":"vincentlli","SECURITYSESSIONID":"186a3","COMMAND_MODE":"unix2003","__CFBundleIdentifier":"com.tencent.codebuddycn","PATH":"/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/3823_1764301444320/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin:/Users/vincentlli/Documents/demo/h265/emsdk:/Users/vincentlli/Documents/demo/h265/emsdk/upstream/emscripten:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Library/Apple/usr/bin:/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/1172_1764301439509/bin:/Users/vincentlli/.deno/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/micromamba/condabin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","HOME":"/Users/vincentlli","SHELL":"/bin/zsh","LaunchInstanceID":"A4C3CE65-561F-40EB-8850-E06A56601406","__CF_USER_TEXT_ENCODING":"0x1F6:0x19:0x34","XPC_SERVICE_NAME":"0","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.4cmc7UUAl7/Listeners","XPC_FLAGS":"0x0","LOGNAME":"vincentlli","TMPDIR":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","SHLVL":"1","PWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","OLDPWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","HOMEBREW_PREFIX":"/opt/homebrew","HOMEBREW_CELLAR":"/opt/homebrew/Cellar","HOMEBREW_REPOSITORY":"/opt/homebrew","INFOPATH":"/opt/homebrew/share/info:/opt/homebrew/share/info:","EMSDK":"/Users/vincentlli/Documents/demo/h265/emsdk","EMSDK_NODE":"/Users/vincentlli/Documents/demo/h265/emsdk/node/16.20.0_64bit/bin/node","EMSDK_PYTHON":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/bin/python3","SSL_CERT_FILE":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/lib/python3.9/site-packages/certifi/cacert.pem","NVM_DIR":"/Users/vincentlli/.nvm","NVM_CD_FLAGS":"-q","NVM_BIN":"/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","NVM_INC":"/Users/vincentlli/.nvm/versions/node/v20.16.0/include/node","MAMBA_EXE":"/Users/vincentlli/.micromamba/bin/micromamba","MAMBA_ROOT_PREFIX":"/Users/vincentlli/micromamba","CONDA_SHLVL":"0","FNM_MULTISHELL_PATH":"/Users/vincentlli/.local/state/fnm_multishells/3823_1764301444320","FNM_VERSION_FILE_STRATEGY":"local","FNM_DIR":"/Users/vincentlli/.local/share/fnm","FNM_LOGLEVEL":"info","FNM_NODE_DIST_MIRROR":"https://nodejs.org/dist","FNM_COREPACK_ENABLED":"false","FNM_RESOLVE_ENGINES":"true","FNM_ARCH":"arm64","TERM_PROGRAM":"codebuddy","TERM_PROGRAM_VERSION":"1.100.0","LANG":"zh_CN.UTF-8","COLORTERM":"truecolor","GIT_ASKPASS":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass.sh","VSCODE_GIT_ASKPASS_NODE":"/Applications/CodeBuddy CN.app/Contents/Frameworks/CodeBuddy CN Helper (Plugin).app/Contents/MacOS/CodeBuddy CN Helper (Plugin)","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass-main.js","VSCODE_GIT_IPC_HANDLE":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/vscode-git-b9fbf10dc9.sock","VSCODE_INJECTION":"1","ZDOTDIR":"/Users/vincentlli","USER_ZDOTDIR":"/Users/vincentlli","TERM":"xterm-256color","VSCODE_PROFILE_INITIALIZED":"1","_":"/Users/vincentlli/.local/state/fnm_multishells/3823_1764301444320/bin/edgeone","XXX":"123","EDGEONE_MIDDLEWARE":"1","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil: event.waitUntil }))});
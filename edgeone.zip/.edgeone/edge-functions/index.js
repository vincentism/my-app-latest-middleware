
      let global = globalThis;

      if (typeof global.navigator === 'undefined') {
        global.navigator = {
          userAgent: 'edge-runtime',
          language: 'en-US',
          languages: ['en-US'],
        };
      } else {
        if (typeof global.navigator.language === 'undefined') {
          global.navigator.language = 'en-US';
        }
        if (!global.navigator.languages || global.navigator.languages.length === 0) {
          global.navigator.languages = [global.navigator.language];
        }
        if (typeof global.navigator.userAgent === 'undefined') {
          global.navigator.userAgent = 'edge-runtime';
        }
      }

      class MessageChannel {
        constructor() {
          this.port1 = new MessagePort();
          this.port2 = new MessagePort();
        }
      }
      class MessagePort {
        constructor() {
          this.onmessage = null;
        }
        postMessage(data) {
          if (this.onmessage) {
            setTimeout(() => this.onmessage({ data }), 0);
          }
        }
      }
      global.MessageChannel = MessageChannel;

      if ((typeof globalThis.fetch === 'undefined' || typeof globalThis.Headers === 'undefined' || typeof globalThis.Request === 'undefined' || typeof globalThis.Response === 'undefined') && typeof require !== 'undefined') {
        try {
          const undici = require('undici');
          if (undici.fetch && !globalThis.fetch) {
            globalThis.fetch = undici.fetch;
          }
          if (undici.Headers && typeof globalThis.Headers === 'undefined') {
            globalThis.Headers = undici.Headers;
          }
          if (undici.Request && typeof globalThis.Request === 'undefined') {
            globalThis.Request = undici.Request;
          }
          if (undici.Response && typeof globalThis.Response === 'undefined') {
            globalThis.Response = undici.Response;
          }
        } catch (polyfillError) {
          console.warn('Edge middleware polyfill failed:', polyfillError && polyfillError.message ? polyfillError.message : polyfillError);
        }
      }

      function recreateRequest(request, overrides = {}) {
        const cloned = typeof request.clone === 'function' ? request.clone() : request;
        const headers = new Headers(cloned.headers);

        if (overrides.headerPatches) {
          Object.keys(overrides.headerPatches).forEach((key) => {
            const value = overrides.headerPatches[key];
            if (value === null || typeof value === 'undefined') {
              headers.delete(key);
            } else {
              headers.set(key, value);
            }
          });
        }

        if (overrides.headers) {
          const extraHeaders = new Headers(overrides.headers);
          extraHeaders.forEach((value, key) => headers.set(key, value));
        }

        const url = overrides.url || cloned.url;
        const method = overrides.method || cloned.method || 'GET';
        const canHaveBody = method && method.toUpperCase() !== 'GET' && method.toUpperCase() !== 'HEAD';
        const body = overrides.body !== undefined ? overrides.body : canHaveBody ? cloned.body : undefined;

        const init = {
          method,
          headers,
          redirect: cloned.redirect,
          credentials: cloned.credentials,
          cache: cloned.cache,
          mode: cloned.mode,
          referrer: cloned.referrer,
          referrerPolicy: cloned.referrerPolicy,
          integrity: cloned.integrity,
          keepalive: cloned.keepalive,
          signal: cloned.signal,
        };

        if (canHaveBody && body !== undefined) {
          init.body = body;
        }

        if ('duplex' in cloned) {
          init.duplex = cloned.duplex;
        }

        return new Request(url, init);
      }

      
    const __middlewareModule = (() => {
      const module = { exports: {} };
      const exports = module.exports;
      const loader = new Function('module', 'exports', "\"use strict\";var o=Object.defineProperty;var a=Object.getOwnPropertyDescriptor;var s=Object.getOwnPropertyNames;var d=Object.prototype.hasOwnProperty;var l=(e,t)=>{for(var i in t)o(e,i,{get:t[i],enumerable:!0})},m=(e,t,i,r)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let n of s(t))!d.call(e,n)&&n!==i&&o(e,n,{get:()=>t[n],enumerable:!(r=a(t,n))||r.enumerable});return e};var c=e=>m(o({},\"__esModule\",{value:!0}),e);var g={};l(g,{config:()=>p,middleware:()=>w});module.exports=c(g);function w(e){let{redirect:t,rewrite:i,geo:r,clientIp:n,env:u,waitUntil:f}=e;return console.log(\"request in middleware\",e.url),new Response(JSON.stringify({message:\"\\u6D4B\\u8BD5 middleware \\u54CD\\u5E94\",timestamp:new Date().toISOString()}),{status:200,headers:{\"Content-Type\":\"application/json\",\"X-middleware-text\":\"middleware\"}})}var p={matcher:[\"/normal\"]};0&&(module.exports={config,middleware});\n");
      loader(module, exports);
      return module.exports || exports;
    })();

    const middlewareFunction = (() => {
      if (__middlewareModule && typeof __middlewareModule.middleware === 'function') {
        return __middlewareModule.middleware;
      }
      if (
        __middlewareModule &&
        __middlewareModule.default &&
        typeof __middlewareModule.default.middleware === 'function'
      ) {
        return __middlewareModule.default.middleware;
      }
      throw new Error('Middleware bundle did not export a function named "middleware".');
    })();

    function toHeaders(initHeaders) {
      // if (initHeaders instanceof Headers) {
      //   return new Headers(initHeaders);
      // }
      return new Headers(initHeaders ?? {});
    }

    function headersInitToRecord(input) {
      if (!input) {
        return {};
      }
      const record = {};
      const headers = new Headers(input);
      headers.forEach((value, key) => {
        record[key] = value;
      });
      return record;
    }

    function extractRequestHeaderPatch(requestOverrides, fallbackHeaders) {
      const directHeaders = requestOverrides?.headers ? headersInitToRecord(requestOverrides.headers) : null;
      if (directHeaders && Object.keys(directHeaders).length) {
        return directHeaders;
      }
      if (fallbackHeaders) {
        const fallback = headersInitToRecord(fallbackHeaders);
        if (Object.keys(fallback).length) {
          return fallback;
        }
      }
      return null;
    }

    /**
     * next() 函数 - 用于中间件继续执行后续逻辑
     * 返回带有 x-middleware-next 标记的响应
     */
    function next(init) {
      const responseInit = init ?? {};
      const { request: requestOverrides, headers: responseHeadersInit, ...rest } = responseInit;
      const headers = toHeaders(responseHeadersInit);
      headers.set("x-middleware-next", "1");

      const requestHeadersPatch = extractRequestHeaderPatch(requestOverrides, responseHeadersInit);
      if (requestHeadersPatch) {
        try {
          headers.set(
            "x-middleware-request-headers",
            encodeURIComponent(JSON.stringify(requestHeadersPatch))
          );
        } catch (serializationError) {
          console.warn('Failed to serialize middleware request headers patch:', serializationError);
        }
      }
      return new Response(null, {
        ...rest,
        headers,
      });
    }

    function redirect(url, status = 307) {
      return new Response(null, {
        status,
        headers: {
          Location: url
        }
      });
    }

    function rewrite(url) {
      const headers = new Headers();
      headers.set("x-middleware-next", "1");
      headers.set("x-middleware-rewrite", url);
      return new Response(null, { headers });
    }

    // 中间件配置
    const middlewareConfig = {"runtime":"edge","matcher":["/normal"],"normalizedMatcher":[{"source":"/normal","regex":"^\\/normal[\\/#\\?]?$"}]};

    /**
     * 执行中间件并返回响应（如果中间件返回了响应）
     * @param {Object} context - 包含 request, urlInfo, env, waitUntil 的上下文
     * @returns {Response|null} 如果中间件返回响应则返回，否则返回 null
     */
    async function executeMiddleware(context) {
      const { request, urlInfo, env, waitUntil } = context;
      const pathname = urlInfo.pathname;
      
      // 检查路径是否匹配 matcher
      const matchers = [{"source":"/normal","regex":"^\\/normal[\\/#\\?]?$"}];
      let shouldExecute = matchers.length === 0; // 如果没有配置 matcher，默认执行
      
      for (const matcher of matchers) {
        if (matchPattern(pathname, matcher)) {
          shouldExecute = true;
          break;
        }
      }
      
      if (!shouldExecute) {
        return null; // 不匹配，继续执行后续函数
      }
      
      try {
        const middlewareContext = {
          request,
          urlInfo,
          env,
          waitUntil,
          next,
          redirect,
          rewrite,
          geo: {},
          clientIp: request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || '',
        };
        
        // 执行中间件
        const result = await middlewareFunction(middlewareContext);
        
        // 如果返回了 Response 对象，直接返回
        if (result && result instanceof Response) {
          return result;
        }
        
        return null; // 继续执行后续函数
      } catch (error) {
        console.error('Middleware error:', error);
        return null; // 出错时继续执行后续函数
      }
    }
    
    /**
     * 匹配路径模式
     * 支持通配符 * 和精确匹配
     */
    function matchPattern(pathname, matcher) {
      if (!matcher) {
        return false;
      }

      if (matcher.regex === '.*') {
        return true;
      }

      try {
        const regex = new RegExp(matcher.regex);
        return regex.test(pathname);
      } catch (_) {
        return pathname === matcher.source;
      }
    }
  

      async function handleRequest(context){
        let routeParams = {};
        let pagesFunctionResponse = null;
        let request = context.request;
        const waitUntil = context.waitUntil;
        let urlInfo = new URL(request.url);

        const normalizePathname = () => {
          if (urlInfo.pathname !== '/' && urlInfo.pathname.endsWith('/')) {
            urlInfo.pathname = urlInfo.pathname.slice(0, -1);
          }
        };

        normalizePathname();

        let matchedFunc = false;

        
        const runEdgeFunctions = () => {
        
          if(!matchedFunc && '/api' === urlInfo.pathname) {
            matchedFunc = true;
              "use strict";
(() => {
  // edge-functions/api/index.js
  function onRequest(context) {
    return new Response("Hello from Edge Functions!");
  }

        pagesFunctionResponse = onRequest;
      })();
          }
        
        };
        

        const middlewareRequest = request && typeof request.clone === 'function' ? request.clone() : request;
        // 中间件函数在这里执行，并获取返回值
        const middlewareResponse = await executeMiddleware({
          request: middlewareRequest,
          urlInfo: new URL(urlInfo.toString()),
          env: {"MallocNanoZone":"0","USER":"vincentlli","SECURITYSESSIONID":"186a5","COMMAND_MODE":"unix2003","__CFBundleIdentifier":"com.tencent.codebuddycn","PATH":"/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin:/Users/vincentlli/Documents/demo/h265/emsdk:/Users/vincentlli/Documents/demo/h265/emsdk/upstream/emscripten:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Library/Apple/usr/bin:/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/1274_1765421029810/bin:/Users/vincentlli/.deno/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/micromamba/condabin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","HOME":"/Users/vincentlli","SHELL":"/bin/zsh","LaunchInstanceID":"A2299401-C8BC-4380-B437-D48886E467A4","__CF_USER_TEXT_ENCODING":"0x1F6:0x19:0x34","XPC_SERVICE_NAME":"0","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.Q3XqXNWJPW/Listeners","XPC_FLAGS":"0x0","LOGNAME":"vincentlli","TMPDIR":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","SHLVL":"1","PWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","OLDPWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","HOMEBREW_PREFIX":"/opt/homebrew","HOMEBREW_CELLAR":"/opt/homebrew/Cellar","HOMEBREW_REPOSITORY":"/opt/homebrew","INFOPATH":"/opt/homebrew/share/info:/opt/homebrew/share/info:","EMSDK":"/Users/vincentlli/Documents/demo/h265/emsdk","EMSDK_NODE":"/Users/vincentlli/Documents/demo/h265/emsdk/node/16.20.0_64bit/bin/node","EMSDK_PYTHON":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/bin/python3","SSL_CERT_FILE":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/lib/python3.9/site-packages/certifi/cacert.pem","NVM_DIR":"/Users/vincentlli/.nvm","NVM_CD_FLAGS":"-q","NVM_BIN":"/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","NVM_INC":"/Users/vincentlli/.nvm/versions/node/v20.16.0/include/node","MAMBA_EXE":"/Users/vincentlli/.micromamba/bin/micromamba","MAMBA_ROOT_PREFIX":"/Users/vincentlli/micromamba","CONDA_SHLVL":"0","FNM_MULTISHELL_PATH":"/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856","FNM_VERSION_FILE_STRATEGY":"local","FNM_DIR":"/Users/vincentlli/.local/share/fnm","FNM_LOGLEVEL":"info","FNM_NODE_DIST_MIRROR":"https://nodejs.org/dist","FNM_COREPACK_ENABLED":"false","FNM_RESOLVE_ENGINES":"true","FNM_ARCH":"arm64","TERM_PROGRAM":"codebuddy","TERM_PROGRAM_VERSION":"1.100.0","LANG":"zh_CN.UTF-8","COLORTERM":"truecolor","GIT_ASKPASS":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass.sh","VSCODE_GIT_ASKPASS_NODE":"/Applications/CodeBuddy CN.app/Contents/Frameworks/CodeBuddy CN Helper (Plugin).app/Contents/MacOS/CodeBuddy CN Helper (Plugin)","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass-main.js","VSCODE_GIT_IPC_HANDLE":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/vscode-git-b9fbf10dc9.sock","TERM":"xterm-256color","_":"/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856/bin/edgeone","XXX":"123","EDGEONE_MIDDLEWARE":"1","NEXT_PRIVATE_STANDALONE":"true"},
          waitUntil
        });

        // 处理中间件返回值
        if (middlewareResponse) {
          const headers = middlewareResponse.headers;
          const hasNext = headers && headers.get('x-middleware-next') === '1';
          const rewriteTarget = headers && headers.get('x-middleware-rewrite');
          const requestHeadersOverride = headers && headers.get('x-middleware-request-headers');

          if (rewriteTarget) {
            try {
              const rewrittenUrl = rewriteTarget.startsWith('http://') || rewriteTarget.startsWith('https://')
                ? rewriteTarget
                : new URL(rewriteTarget, urlInfo.origin).toString();
              request = recreateRequest(request, { url: rewrittenUrl });
              urlInfo = new URL(rewrittenUrl);
              normalizePathname();
            } catch (rewriteError) {
              console.error('Middleware rewrite error:', rewriteError);
            }
          }

          if (requestHeadersOverride) {
            try {
              const decoded = decodeURIComponent(requestHeadersOverride);
              const headerPatch = JSON.parse(decoded);
              request = recreateRequest(request, { headerPatches: headerPatch });
            } catch (requestPatchError) {
              console.error('Middleware request header override error:', requestPatchError);
            }
          }

          if (!hasNext && !rewriteTarget) {
            return middlewareResponse;
          }
        }
        
        // 走到这里说明：
        // 1. 没有中间件响应（middlewareResponse 为 null/undefined）
        // 2. 或者中间件返回了 next
        // 需要判断是否命中边缘函数

        runEdgeFunctions();

        if (!matchedFunc) {
          // 没有命中边缘函数，执行回源
          return fetch(request);
        }
        
        // 命中了边缘函数，继续执行边缘函数逻辑

        const params = {};
        if (routeParams.id) {
          if (routeParams.mode === 1) {
            const value = urlInfo.pathname.match(routeParams.left);        
            for (let i = 1; i < value.length; i++) {
              params[routeParams.id[i - 1]] = value[i];
            }
          } else {
            const value = urlInfo.pathname.replace(routeParams.left, '');
            const splitedValue = value.split('/');
            if (splitedValue.length === 1) {
              params[routeParams.id] = splitedValue[0];
            } else {
              params[routeParams.id] = splitedValue;
            }
          }
          
        }
        if(!matchedFunc){
          // 没有匹配到边缘函数，返回 404
          pagesFunctionResponse = function() {
            return new Response(null, {
              status: 404,
              headers: {
                "content-type": "text/html; charset=UTF-8",
                "x-edgefunctions-test": "Welcome to use Pages Functions.",
              },
            });
          }
        }
        return pagesFunctionResponse({request, params, env: {"MallocNanoZone":"0","USER":"vincentlli","SECURITYSESSIONID":"186a5","COMMAND_MODE":"unix2003","__CFBundleIdentifier":"com.tencent.codebuddycn","PATH":"/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin:/Users/vincentlli/Documents/demo/h265/emsdk:/Users/vincentlli/Documents/demo/h265/emsdk/upstream/emscripten:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Library/Apple/usr/bin:/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/1274_1765421029810/bin:/Users/vincentlli/.deno/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/micromamba/condabin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","HOME":"/Users/vincentlli","SHELL":"/bin/zsh","LaunchInstanceID":"A2299401-C8BC-4380-B437-D48886E467A4","__CF_USER_TEXT_ENCODING":"0x1F6:0x19:0x34","XPC_SERVICE_NAME":"0","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.Q3XqXNWJPW/Listeners","XPC_FLAGS":"0x0","LOGNAME":"vincentlli","TMPDIR":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","SHLVL":"1","PWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","OLDPWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","HOMEBREW_PREFIX":"/opt/homebrew","HOMEBREW_CELLAR":"/opt/homebrew/Cellar","HOMEBREW_REPOSITORY":"/opt/homebrew","INFOPATH":"/opt/homebrew/share/info:/opt/homebrew/share/info:","EMSDK":"/Users/vincentlli/Documents/demo/h265/emsdk","EMSDK_NODE":"/Users/vincentlli/Documents/demo/h265/emsdk/node/16.20.0_64bit/bin/node","EMSDK_PYTHON":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/bin/python3","SSL_CERT_FILE":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/lib/python3.9/site-packages/certifi/cacert.pem","NVM_DIR":"/Users/vincentlli/.nvm","NVM_CD_FLAGS":"-q","NVM_BIN":"/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","NVM_INC":"/Users/vincentlli/.nvm/versions/node/v20.16.0/include/node","MAMBA_EXE":"/Users/vincentlli/.micromamba/bin/micromamba","MAMBA_ROOT_PREFIX":"/Users/vincentlli/micromamba","CONDA_SHLVL":"0","FNM_MULTISHELL_PATH":"/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856","FNM_VERSION_FILE_STRATEGY":"local","FNM_DIR":"/Users/vincentlli/.local/share/fnm","FNM_LOGLEVEL":"info","FNM_NODE_DIST_MIRROR":"https://nodejs.org/dist","FNM_COREPACK_ENABLED":"false","FNM_RESOLVE_ENGINES":"true","FNM_ARCH":"arm64","TERM_PROGRAM":"codebuddy","TERM_PROGRAM_VERSION":"1.100.0","LANG":"zh_CN.UTF-8","COLORTERM":"truecolor","GIT_ASKPASS":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass.sh","VSCODE_GIT_ASKPASS_NODE":"/Applications/CodeBuddy CN.app/Contents/Frameworks/CodeBuddy CN Helper (Plugin).app/Contents/MacOS/CodeBuddy CN Helper (Plugin)","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass-main.js","VSCODE_GIT_IPC_HANDLE":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/vscode-git-b9fbf10dc9.sock","TERM":"xterm-256color","_":"/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856/bin/edgeone","XXX":"123","EDGEONE_MIDDLEWARE":"1","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil });
      }
      addEventListener('fetch', event=>{return event.respondWith(handleRequest({request:event.request,params: {}, env: {"MallocNanoZone":"0","USER":"vincentlli","SECURITYSESSIONID":"186a5","COMMAND_MODE":"unix2003","__CFBundleIdentifier":"com.tencent.codebuddycn","PATH":"/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin:/Users/vincentlli/Documents/demo/h265/emsdk:/Users/vincentlli/Documents/demo/h265/emsdk/upstream/emscripten:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/Library/Apple/usr/bin:/Users/vincentlli/.codebuddy/bin:/Users/vincentlli/.local/state/fnm_multishells/1274_1765421029810/bin:/Users/vincentlli/.deno/bin:/Users/vincentlli/anaconda3/bin:/Users/vincentlli/micromamba/condabin:/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","HOME":"/Users/vincentlli","SHELL":"/bin/zsh","LaunchInstanceID":"A2299401-C8BC-4380-B437-D48886E467A4","__CF_USER_TEXT_ENCODING":"0x1F6:0x19:0x34","XPC_SERVICE_NAME":"0","SSH_AUTH_SOCK":"/private/tmp/com.apple.launchd.Q3XqXNWJPW/Listeners","XPC_FLAGS":"0x0","LOGNAME":"vincentlli","TMPDIR":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","SHLVL":"1","PWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","OLDPWD":"/Users/vincentlli/Documents/demo/netlify/my-app-latest","HOMEBREW_PREFIX":"/opt/homebrew","HOMEBREW_CELLAR":"/opt/homebrew/Cellar","HOMEBREW_REPOSITORY":"/opt/homebrew","INFOPATH":"/opt/homebrew/share/info:/opt/homebrew/share/info:","EMSDK":"/Users/vincentlli/Documents/demo/h265/emsdk","EMSDK_NODE":"/Users/vincentlli/Documents/demo/h265/emsdk/node/16.20.0_64bit/bin/node","EMSDK_PYTHON":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/bin/python3","SSL_CERT_FILE":"/Users/vincentlli/Documents/demo/h265/emsdk/python/3.9.2_64bit/lib/python3.9/site-packages/certifi/cacert.pem","NVM_DIR":"/Users/vincentlli/.nvm","NVM_CD_FLAGS":"-q","NVM_BIN":"/Users/vincentlli/.nvm/versions/node/v20.16.0/bin","NVM_INC":"/Users/vincentlli/.nvm/versions/node/v20.16.0/include/node","MAMBA_EXE":"/Users/vincentlli/.micromamba/bin/micromamba","MAMBA_ROOT_PREFIX":"/Users/vincentlli/micromamba","CONDA_SHLVL":"0","FNM_MULTISHELL_PATH":"/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856","FNM_VERSION_FILE_STRATEGY":"local","FNM_DIR":"/Users/vincentlli/.local/share/fnm","FNM_LOGLEVEL":"info","FNM_NODE_DIST_MIRROR":"https://nodejs.org/dist","FNM_COREPACK_ENABLED":"false","FNM_RESOLVE_ENGINES":"true","FNM_ARCH":"arm64","TERM_PROGRAM":"codebuddy","TERM_PROGRAM_VERSION":"1.100.0","LANG":"zh_CN.UTF-8","COLORTERM":"truecolor","GIT_ASKPASS":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass.sh","VSCODE_GIT_ASKPASS_NODE":"/Applications/CodeBuddy CN.app/Contents/Frameworks/CodeBuddy CN Helper (Plugin).app/Contents/MacOS/CodeBuddy CN Helper (Plugin)","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"/Applications/CodeBuddy CN.app/Contents/Resources/app/extensions/git/dist/askpass-main.js","VSCODE_GIT_IPC_HANDLE":"/var/folders/3z/jtwy8_190w3c74yyzhd5wz580000gp/T/vscode-git-b9fbf10dc9.sock","TERM":"xterm-256color","_":"/Users/vincentlli/.local/state/fnm_multishells/7493_1765421048856/bin/edgeone","XXX":"123","EDGEONE_MIDDLEWARE":"1","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil: event.waitUntil }))});
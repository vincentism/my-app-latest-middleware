module.exports=[23593,(a,b,c)=>{}];

//# sourceMappingURL=netlify_my-app-latest__next-internal_server_app_zh_page_actions_53da0795.js.map
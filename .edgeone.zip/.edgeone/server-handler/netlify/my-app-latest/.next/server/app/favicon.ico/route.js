var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_b89b5a39._.js")
R.c("server/chunks/[root-of-the-server]__6aa62702._.js")
R.c("server/chunks/af5ec_my-app-latest__next-internal_server_app_favicon_ico_route_actions_e7cd398f.js")
R.m(15790)
module.exports=R.m(15790).exports

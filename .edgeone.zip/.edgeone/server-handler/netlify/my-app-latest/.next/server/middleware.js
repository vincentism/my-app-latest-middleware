var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]_next_dist_server_app-render_7c4bb6f7._.js")
R.c("server/chunks/[root-of-the-server]__3aece102._.js")
R.m(20641)
module.exports=R.m(20641).exports
